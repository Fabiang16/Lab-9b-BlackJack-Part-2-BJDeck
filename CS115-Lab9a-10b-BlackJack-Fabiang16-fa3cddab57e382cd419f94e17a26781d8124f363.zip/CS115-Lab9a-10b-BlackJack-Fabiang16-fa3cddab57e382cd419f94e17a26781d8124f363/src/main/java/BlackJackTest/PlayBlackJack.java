package BlackJackTest;

import BlackJack.BJDeck;
import BlackJack.BJCard;
import BlackJackBase.PCard;
import BlackJackBase.PDeck;

public class PlayBlackJack {
    public static void main(String[] args) {

        BJDeck deck = new BJDeck();


        System.out.println("Cards in the deck: " + deck.cardCount());


        DeckTest.run(deck);

        PCard dealtCard = deck.dealCard();
        System.out.println("Card dealt: " + dealtCard.getText());
        System.out.println("Remaining cards in the deck: " + deck.cardCount());

        PCard hiddenCard = deck.dealHiddenCard();
        System.out.println("Hidden card dealt.");
        System.out.println("Remaining cards in the deck: " + deck.cardCount());
    }
}

