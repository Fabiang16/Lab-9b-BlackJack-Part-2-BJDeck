package BlackJack;

import BlackJackBase.PCard;
import java.awt.Color;

public class BJCard extends PCard {

    public static final int ACE = 1;
    public static final int TWO = 2;
    public static final int THREE = 3;
    public static final int FOUR = 4;
    public static final int FIVE = 5;
    public static final int SIX = 6;
    public static final int SEVEN = 7;
    public static final int EIGHT = 8;
    public static final int NINE = 9;
    public static final int TEN = 10;
    public static final int JACK = 11;
    public static final int KNIGHT = 12;
    public static final int QUEEN = 13;
    public static final int KING = 14;

    public static final int SPADE = 1;
    public static final int HEART = 2;
    public static final int DIAMOND = 3;
    public static final int CLUB = 4;

    private int rank;
    private int suit;
    private boolean hidden;

    public BJCard(int rank, int suit) {
        this.rank = rank;
        this.suit = suit;
        this.hidden = false;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public int getSuit() {
        return suit;
    }

    public void setSuit(int suit) {
        this.suit = suit;
    }

    @Override
    public void hideCard() {
        hidden = true;
    }

    @Override
    public void showCard() {
        hidden = false;
    }

    @Override
    public boolean isHidden() {
        return hidden;
    }

    @Override
    public String getText() {
        if (hidden) {
            return "??";
        }
        return getRankString() + getSuitSymbol();
    }

    private String getRankString() {
        return switch (rank) {
            case ACE -> "A";
            case TWO -> "2";
            case THREE -> "3";
            case FOUR -> "4";
            case FIVE -> "5";
            case SIX -> "6";
            case SEVEN -> "7";
            case EIGHT -> "8";
            case NINE -> "9";
            case TEN -> "10";
            case JACK -> "J";
            case KNIGHT -> "Kn";
            case QUEEN -> "Q";
            case KING -> "K";
            default -> "?";
        };
    }

    private String getSuitSymbol() {
        return switch (suit) {
            case SPADE -> "♠"; // ♠
            case HEART -> "♥"; // ♥
            case DIAMOND -> "♦"; // ♦
            case CLUB -> "♣"; // ♣
            default -> "?";
        };
    }

    @Override
    public Color getFontColor() {
        if (suit == HEART || suit == DIAMOND) {
            return Color.RED;
        } else {
            return Color.BLACK;
        }
    }

    @Override
    public Color getBorderColor() {
        return Color.BLACK;
    }

    @Override
    public Color getFaceColor() {
        return Color.WHITE;
    }

    @Override
    public Color getBackColor() {
        return Color.LIGHT_GRAY;
    }

    @Override
    public Color getStripeColor() {
        return Color.GRAY;
    }
}

