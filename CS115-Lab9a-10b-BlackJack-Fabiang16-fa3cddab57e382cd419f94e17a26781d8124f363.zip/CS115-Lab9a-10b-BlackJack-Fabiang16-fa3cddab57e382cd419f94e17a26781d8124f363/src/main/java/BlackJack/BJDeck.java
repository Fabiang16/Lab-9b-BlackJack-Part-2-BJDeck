package BlackJack;

import BlackJackBase.PCard;
import BlackJackBase.PDeck;
import java.util.ArrayList;
import java.util.Collections;

public class BJDeck implements PDeck {
    private ArrayList<PCard> cards;

    public BJDeck() {
        cards = new ArrayList<>();
        for (int suit = 1; suit <= 4; suit++) {
            for (int rank = 1; rank <= 13; rank++) {
                cards.add(new BJCard(rank, suit));
                System.out.println("Added: " + new BJCard(rank, suit).getText());
            }
        }
    }

    @Override
    public void shuffle() {
        Collections.shuffle(cards);
    }

    @Override
    public void addCard(PCard card) {
        cards.add(card);
    }

    @Override
    public PCard dealCard() {
        if (cards.isEmpty()) {
            return null;
        }
        return cards.remove(0);
    }

    @Override
    public PCard dealHiddenCard() {
        if (cards.isEmpty()) {
            return null;
        }
        PCard card = cards.remove(0);
        return card;
    }

    @Override
    public int cardCount() {
        return cards.size();
    }
}



